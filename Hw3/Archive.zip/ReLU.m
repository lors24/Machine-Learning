function [output] = ReLU(z)
%ReLU function from R->R
%Input: z in R
%Output: max(0,z)

output = max(0,z);
end

